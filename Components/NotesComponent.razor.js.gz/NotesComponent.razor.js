export class NotesComponent {
  
}

window.NotesComponent = NotesComponent;