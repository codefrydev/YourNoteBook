export class ShortcutComponent {
  
}

window.ShortcutComponent = ShortcutComponent;