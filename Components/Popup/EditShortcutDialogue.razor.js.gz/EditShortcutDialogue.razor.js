export class EditShortcutDialogue {
  
}

window.EditShortcutDialogue = EditShortcutDialogue;