export class RenameDialogue {
  
}

window.RenameDialogue = RenameDialogue;