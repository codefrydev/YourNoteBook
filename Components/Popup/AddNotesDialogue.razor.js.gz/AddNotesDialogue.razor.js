export class AddNotesDialogue {
  
}

window.AddNotesDialogue = AddNotesDialogue;