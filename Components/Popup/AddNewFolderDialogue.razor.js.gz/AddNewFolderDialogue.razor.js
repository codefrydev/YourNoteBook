export class AddNewFolderDialogue {
  
}

window.AddNewFolderDialogue = AddNewFolderDialogue;