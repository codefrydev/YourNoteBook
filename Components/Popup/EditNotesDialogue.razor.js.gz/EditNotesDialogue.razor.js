export class EditNotesDialogue {
  
}

window.EditNotesDialogue = EditNotesDialogue;