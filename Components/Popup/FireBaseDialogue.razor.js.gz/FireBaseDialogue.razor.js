export class FireabseDialogue {
  
}

window.FireabseDialogue = FireabseDialogue;