export class AddShortcutDialogue {
  
}

window.AddShortcutDialogue = AddShortcutDialogue;