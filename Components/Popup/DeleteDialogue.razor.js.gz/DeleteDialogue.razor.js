export class DeleteDialogue {
  
}

window.DeleteDialogue = DeleteDialogue;