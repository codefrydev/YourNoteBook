export class FolderComponent {
  
}

window.FolderComponent = FolderComponent;